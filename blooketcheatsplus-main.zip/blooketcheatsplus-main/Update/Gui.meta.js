// ==UserScript==
// @name         Blooket Cheats Plus
// @namespace    https://github.com/randomstuff69/blooketcheatsplus
// @version      15
// @description  adds cheats from blooketbot.glitch.me to the 05konz gui
// @updateURL    https://raw.githubusercontent.com/randomstuff69/blooketcheatsplus/main/Update/Gui.meta.js
// @downloadURL  https://raw.githubusercontent.com/randomstuff69/blooketcheatsplus/main/GUI/Gui.user.js
// @author       DannyDan0167 and Cool Duck
// @match        *://*.blooket.com/*
// @icon         https://i.ibb.co/sWqBm0K/1024.png
// @grant        none
// @require     https://raw.githubusercontent.com/randomstuff69/blooketcheatsplus/refs/heads/main/GUI/Gui.js
// @license MIT
// ==/UserScript==

