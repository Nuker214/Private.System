<h2 align="center">Laser Tag Cheats</h2>
<h3>Keybinds:</h3>
<ul><li>g: activates auto fire</li><li>f: activates freecam</li><li>1: toggles player esp</li><li>2: toggles target esp</li><li>3: toggles powerup esp</li><li>4: toggles esp line of sight checks (helps with lag in large games)</li><li>scroll wheel: zooms map in/out</li></ul>
<h3>Console commands:</h3>
<ul><li><code>exportAnswers()</code>: Exports all saved answers in a base64 encoded string.</li><li><code>importAnswers("answerstring")</code>: imports the answer string returned from <code>exportAnswers()</code></li></ul>
<div>IMPORTANT NOTES: <ul><li>The Auto Answer collects answers as you play; it is not broken!</li><li>These cheats MUST be run when in the game arena. You CANNOT run them in the lobby before the game loads, or they will not work!</li></ul></div>
