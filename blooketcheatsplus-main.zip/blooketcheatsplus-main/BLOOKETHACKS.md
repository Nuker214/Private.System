these are blooket hacks/cheats https://github.com/randomstuff69/blooketcheatsplus
